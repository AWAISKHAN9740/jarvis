package com.example.jarvis

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.Uri
import android.os.Bundle
import android.os.IBinder
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import kotlinx.coroutines.*
import org.json.JSONObject
import java.util.Locale

/**
 * बैकग्राउंड वॉइस सर्विस (Foreground Service, माइक टाइप)।
 * दो हालतें: (1) "Hey Jarvis" का इंतज़ार  (2) लाइव बातचीत।
 */
class JarvisService : Service() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var rec: SpeechRecognizer? = null
    private var agent: Agent? = null

    private val order = listOf("hi-IN", "en-US", "ur-PK", "ps-AF")
    private var lang = "hi-IN"
    private var conversation = false
    private var busy = false
    private var misses = 0
    private var lastActive = 0L
    private var confirmWait: CompletableDeferred<String>? = null

    private val wake = listOf("jarvis", "jarves", "jarvish", "जार्विस", "जारविस", "जार्वीस", "जार्विज़", "جارویس", "جاروس", "ژارویس")
    private val bye = listOf("bye", "goodbye", "stop listening", "अलविदा", "बंद करो", "बस करो", "बाय", "خدا حافظ", "الوداع", "بس کرو", "بند کرو")
    private val idleText = "सुन रहा हूँ — \"Hey Jarvis\" बोलिए"

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, flags: Int, startId: Int): Int {
        if (i?.action == "STOP") { stopSelf(); return START_NOT_STICKY }
        createChannel()
        startForeground(1, notif(idleText), ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        val key = getSharedPreferences("jarvis", MODE_PRIVATE).getString("api_key", "") ?: ""
        if (key.isBlank()) { stopSelf(); return START_NOT_STICKY }
        if (agent == null) {
            agent = Agent(key) { n, a -> runTool(n, a) }
            tts = TextToSpeech(this) { ttsReady = it == TextToSpeech.SUCCESS }
            listen()
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        scope.cancel()
        rec?.destroy()
        tts?.shutdown()
        super.onDestroy()
    }

    // ---------- सुनना ----------
    private fun listen() {
        if (busy && confirmWait == null) return
        rec?.destroy()
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { updateNotif("इस फोन पर speech recognition उपलब्ध नहीं है"); return }
        val r = SpeechRecognizer.createSpeechRecognizer(this)
        rec = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onResults(b: Bundle?) {
                onHeard(b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: "")
            }
            override fun onError(e: Int) { onFail(e) }
            override fun onReadyForSpeech(p: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(v: Float) {}
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(b: Bundle?) {}
            override fun onEvent(t: Int, b: Bundle?) {}
        })
        val useLang = if (conversation || confirmWait != null) lang else "hi-IN"
        r.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, useLang)
            .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false))
    }

    private fun next(l: String) = order[(order.indexOf(l) + 1) % order.size]

    private fun onFail(e: Int) {
        when (e) {
            SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> { updateNotif("माइक की अनुमति चाहिए"); stopSelf(); return }
            12, 13 -> lang = next(lang) // भाषा सपोर्ट नहीं / उपलब्ध नहीं
            SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT ->
                if (conversation && ++misses >= 2) { misses = 0; lang = next(lang) }
        }
        if (conversation && confirmWait == null && System.currentTimeMillis() - lastActive > 40000) {
            conversation = false
            updateNotif(idleText)
        }
        scope.launch {
            delay(if (e == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) 1000 else 300)
            listen()
        }
    }

    private fun onHeard(raw: String) {
        if (busy && confirmWait == null) return
        val t = raw.trim()
        misses = 0
        if (t.isEmpty()) { listen(); return }
        confirmWait?.let { it.complete(t); return }
        val low = t.lowercase()
        if (!conversation) {
            val w = wake.firstOrNull { low.contains(it) }
            if (w == null) { listen(); return }
            conversation = true
            lastActive = System.currentTimeMillis()
            if (t.length - w.length > 8) process(t)
            else scope.launch { busy = true; speak("जी, बोलिए।"); busy = false; listen() }
            return
        }
        if (bye.any { low.contains(it) }) {
            conversation = false
            updateNotif(idleText)
            scope.launch { busy = true; speak("ठीक है, अलविदा।"); busy = false; listen() }
        } else process(t)
    }

    private fun process(t: String) {
        busy = true
        lastActive = System.currentTimeMillis()
        updateNotif("सुना: $t")
        scope.launch {
            val reply = try { agent!!.ask(t) } catch (e: Exception) { "माफ़ कीजिए, इंटरनेट या API key में दिक्कत है।" }
            lang = recLang(reply)
            updateNotif(reply)
            speak(reply)
            busy = false
            lastActive = System.currentTimeMillis()
            listen()
        }
    }

    // ---------- बोलना ----------
    private fun recLang(t: String) = when {
        Regex("[\\u0900-\\u097F]").containsMatchIn(t) -> "hi-IN"
        Regex("[ټډړږښڼېځڅ]").containsMatchIn(t) -> "ps-AF"
        Regex("[\\u0600-\\u06FF]").containsMatchIn(t) -> "ur-PK"
        else -> "en-US"
    }

    private suspend fun speak(text: String) {
        val t = tts
        if (t == null || !ttsReady || t.setLanguage(Locale.forLanguageTag(recLang(text))) < TextToSpeech.LANG_AVAILABLE) return
        val done = CompletableDeferred<Unit>()
        t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(u: String?) {}
            override fun onDone(u: String?) { done.complete(Unit) }
            @Deprecated("deprecated") override fun onError(u: String?) { done.complete(Unit) }
        })
        t.speak(text.replace(Regex("[*_#`]"), ""), TextToSpeech.QUEUE_FLUSH, null, System.nanoTime().toString())
        withTimeoutOrNull(60000) { done.await() }
    }

    // ---------- अनुमति और टूल ----------
    private suspend fun confirm(q: String): Boolean {
        speak(q)
        val w = CompletableDeferred<String>()
        confirmWait = w
        listen()
        val a = withTimeoutOrNull(15000) { w.await() }
        confirmWait = null
        rec?.cancel()
        return a != null && Safety.isYes(a)
    }

    private fun launch(i: Intent) {
        val ctx = JarvisAccessibilityService.instance ?: this
        ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    private suspend fun runTool(name: String, a: JSONObject): ToolResult {
        val acc = JarvisAccessibilityService.instance
        if (name !in Safety.noConfirm) {
            val q = a.optString("confirm_question").ifBlank { "क्या मैं यह करूँ?" }
            if (!confirm(q)) return ToolResult("User declined or did not answer. Do not retry.")
        }
        fun noA11y() = ToolResult("Accessibility service is off. Ask the user to turn it on in the JARVIS app.")
        return try {
            when (name) {
                "open_app" -> openApp(a.optString("app_name"))
                "open_url" -> {
                    val u = a.optString("url")
                    if (!u.startsWith("https://") && !u.startsWith("http://")) ToolResult("Only http(s) links are allowed.")
                    else { launch(Intent(Intent.ACTION_VIEW, Uri.parse(u))); ToolResult("opened") }
                }
                "dial_number" -> {
                    launch(Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(a.optString("number")))))
                    ToolResult("Dialer opened with the number. The user must press call themselves.")
                }
                "go_home" -> acc?.let { ToolResult(if (it.home()) "done" else "failed") } ?: noA11y()
                "go_back" -> acc?.let { ToolResult(if (it.back()) "done" else "failed") } ?: noA11y()
                "read_screen" -> acc?.let { ToolResult(it.readScreen()) } ?: noA11y()
                "look_at_screen" -> acc?.let {
                    val b = it.screenshotB64()
                    if (b == null) ToolResult("Screenshot blocked or failed (secure or sensitive screen).")
                    else ToolResult("Screenshot attached.", b)
                } ?: noA11y()
                "tap_text" -> acc?.let { ToolResult(it.tap(a.optString("text"))) } ?: noA11y()
                "scroll_down" -> acc?.let { ToolResult(it.scrollDown()) } ?: noA11y()
                else -> ToolResult("unknown tool")
            }
        } catch (e: Exception) { ToolResult("error: ${e.message}") }
    }

    private fun openApp(label: String): ToolResult {
        val pm = packageManager
        val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val m = pm.queryIntentActivities(q, 0).firstOrNull { it.loadLabel(pm).toString().contains(label, true) }
            ?: return ToolResult("No app named $label found. Try the English name.")
        val pkg = m.activityInfo.packageName
        if (Safety.sensitivePackage(pkg)) return ToolResult("BLOCKED: banking/payment/password apps are not allowed.")
        val li = pm.getLaunchIntentForPackage(pkg) ?: return ToolResult("Cannot launch that app.")
        launch(li)
        return ToolResult("opened ${m.loadLabel(pm)}")
    }

    // ---------- नोटिफिकेशन ----------
    private fun createChannel() {
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel("jarvis", "JARVIS", NotificationManager.IMPORTANCE_LOW))
    }

    private fun notif(text: String): Notification {
        val stop = PendingIntent.getService(this, 0, Intent(this, JarvisService::class.java).setAction("STOP"), PendingIntent.FLAG_IMMUTABLE)
        return Notification.Builder(this, "jarvis")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("JARVIS")
            .setContentText(text)
            .setStyle(Notification.BigTextStyle().bigText(text))
            .setOngoing(true)
            .addAction(Notification.Action.Builder(android.R.drawable.ic_menu_close_clear_cancel, "बंद करें", stop).build())
            .build()
    }

    private fun updateNotif(text: String) {
        getSystemService(NotificationManager::class.java).notify(1, notif(text))
    }
}
