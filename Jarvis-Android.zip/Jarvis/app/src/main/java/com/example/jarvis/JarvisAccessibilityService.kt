package com.example.jarvis

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityService.ScreenshotResult
import android.accessibilityservice.AccessibilityService.TakeScreenshotCallback
import android.content.Intent
import android.graphics.Bitmap
import android.util.Base64
import android.view.Display
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import kotlinx.coroutines.suspendCancellableCoroutine
import java.io.ByteArrayOutputStream
import kotlin.coroutines.resume

class JarvisAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile var instance: JarvisAccessibilityService? = null
    }

    override fun onServiceConnected() { instance = this }
    override fun onUnbind(intent: Intent?): Boolean { instance = null; return super.onUnbind(intent) }
    override fun onDestroy() { instance = null; super.onDestroy() }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    fun home() = performGlobalAction(GLOBAL_ACTION_HOME)
    fun back() = performGlobalAction(GLOBAL_ACTION_BACK)

    private fun blockedRoot(root: AccessibilityNodeInfo?) =
        Safety.sensitivePackage(root?.packageName?.toString())

    fun readScreen(): String {
        val root = rootInActiveWindow ?: return "Could not read the screen."
        if (blockedRoot(root)) return "BLOCKED: banking/payment/password app. Do not read."
        val sb = StringBuilder()
        fun walk(n: AccessibilityNodeInfo?) {
            if (n == null || sb.length > 3000) return
            if (!n.isPassword && n.isVisibleToUser) {
                val t = n.text?.toString() ?: n.contentDescription?.toString()
                if (!t.isNullOrBlank()) {
                    sb.append(t.take(200))
                    if (n.isClickable) sb.append(" [button]")
                    sb.append('\n')
                }
            }
            for (i in 0 until n.childCount) walk(n.getChild(i))
        }
        walk(root)
        return "App: ${root.packageName}\n$sb"
    }

    fun tap(label: String): String {
        val root = rootInActiveWindow ?: return "No screen available."
        if (blockedRoot(root)) return "BLOCKED: banking/payment/password app."
        if (Safety.riskyLabel(label)) return "BLOCKED: this looks like a risky button (send/pay/delete...). Ask the user to press it themselves."
        for (c in root.findAccessibilityNodeInfosByText(label)) {
            if (c.isPassword) continue
            var n: AccessibilityNodeInfo? = c
            while (n != null && !n.isClickable) n = n.parent
            if (n != null) {
                val t = (n.text ?: n.contentDescription)?.toString()
                if (Safety.riskyLabel(t)) return "BLOCKED: risky button."
                return if (n.performAction(AccessibilityNodeInfo.ACTION_CLICK)) "clicked" else "click failed"
            }
        }
        return "Button with that text not found on screen."
    }

    fun scrollDown(): String {
        val root = rootInActiveWindow ?: return "No screen available."
        if (blockedRoot(root)) return "BLOCKED"
        val n = findScrollable(root) ?: return "Nothing scrollable here."
        return if (n.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD)) "scrolled" else "scroll failed"
    }

    private fun findScrollable(n: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        if (n.isScrollable) return n
        for (i in 0 until n.childCount) {
            val c = n.getChild(i) ?: continue
            findScrollable(c)?.let { return it }
        }
        return null
    }

    /** स्क्रीन की छोटी JPEG तस्वीर (base64)। सुरक्षित/FLAG_SECURE स्क्रीन पर खाली या null आती है। */
    suspend fun screenshotB64(): String? {
        if (blockedRoot(rootInActiveWindow)) return null
        return suspendCancellableCoroutine { cont ->
            takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : TakeScreenshotCallback {
                override fun onSuccess(r: ScreenshotResult) {
                    try {
                        val hw = Bitmap.wrapHardwareBuffer(r.hardwareBuffer, r.colorSpace)
                        val soft = hw?.copy(Bitmap.Config.ARGB_8888, false)
                        r.hardwareBuffer.close()
                        if (soft == null) { cont.resume(null); return }
                        val w = 900
                        val h = soft.height * w / soft.width
                        val small = Bitmap.createScaledBitmap(soft, w, h, true)
                        val bos = ByteArrayOutputStream()
                        small.compress(Bitmap.CompressFormat.JPEG, 60, bos)
                        cont.resume(Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP))
                    } catch (e: Exception) { cont.resume(null) }
                }
                override fun onFailure(errorCode: Int) { cont.resume(null) }
            })
        }
    }
}
