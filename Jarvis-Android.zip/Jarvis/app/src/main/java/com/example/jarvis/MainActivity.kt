package com.example.jarvis

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.widget.*

class MainActivity : Activity() {
    private lateinit var status: TextView
    private val prefs get() = getSharedPreferences("jarvis", MODE_PRIVATE)

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        val pad = (16 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(pad, pad, pad, pad) }
        setContentView(ScrollView(this).apply { addView(root) })

        fun btn(t: String, f: () -> Unit) {
            root.addView(Button(this).apply { text = t; setOnClickListener { f() } })
        }

        root.addView(TextView(this).apply { text = "JARVIS"; textSize = 26f })
        val key = EditText(this).apply {
            hint = "Claude API key (sk-ant-...)"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setText(prefs.getString("api_key", ""))
        }
        root.addView(key)
        btn("1. API key सेव करें") {
            prefs.edit().putString("api_key", key.text.toString().trim()).apply()
            refresh()
        }
        btn("2. माइक + नोटिफिकेशन की अनुमति दें") {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        btn("3. Accessibility चालू करें") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        btn("4. Display over other apps की अनुमति") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        btn("5. बैटरी: JARVIS को Unrestricted करें") {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        }
        btn("▶ JARVIS चालू करें") {
            when {
                checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED ->
                    Toast.makeText(this, "पहले माइक की अनुमति दें (बटन 2)", Toast.LENGTH_LONG).show()
                prefs.getString("api_key", "").isNullOrBlank() ->
                    Toast.makeText(this, "पहले API key सेव करें (बटन 1)", Toast.LENGTH_LONG).show()
                else -> {
                    startForegroundService(Intent(this, JarvisService::class.java))
                    Toast.makeText(this, "JARVIS चालू। \"Hey Jarvis\" बोलिए।", Toast.LENGTH_LONG).show()
                }
            }
        }
        btn("■ JARVIS बंद करें") {
            startService(Intent(this, JarvisService::class.java).setAction("STOP"))
        }
        status = TextView(this).apply { setPadding(0, pad, 0, 0) }
        root.addView(status)
    }

    override fun onResume() { super.onResume(); refresh() }

    private fun refresh() {
        fun mark(ok: Boolean) = if (ok) "✅" else "❌"
        status.text = "स्थिति\n" +
            "${mark(!prefs.getString("api_key", "").isNullOrBlank())} API key\n" +
            "${mark(checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED)} माइक\n" +
            "${mark(JarvisAccessibilityService.instance != null)} Accessibility\n" +
            "${mark(Settings.canDrawOverlays(this))} Display over other apps"
    }
}
