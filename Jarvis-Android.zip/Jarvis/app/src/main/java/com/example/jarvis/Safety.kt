package com.example.jarvis

/** सारे सुरक्षा नियम एक जगह। यहाँ बदलाव सोच-समझकर करें। */
object Safety {
    // इन ऐप्स की स्क्रीन JARVIS न पढ़ेगा, न इनमें कुछ दबाएगा, न इन्हें खोलेगा।
    private val sensitivePkgWords = listOf(
        "bank", "pay", "paisa", "wallet", "upi", "paytm", "phonepe", "gpay", "finance",
        "password", "authenticator", "keepass", "bitwarden", "lastpass", "dashlane", "sbi", "hdfc", "icici"
    )

    // इन शब्दों वाले बटन JARVIS कभी नहीं दबाएगा (अंदाज़ी सूची, ज़रूरत हो तो बढ़ाइए)।
    private val riskyLabelWords = listOf(
        "send", "pay", "delete", "remove", "buy", "purchase", "transfer", "install", "uninstall",
        "place order", "sign out", "log out", "erase", "reset", "call", "submit",
        "भेज", "भुगतान", "हटा", "डिलीट", "खरीद", "इंस्टॉल", "साइन आउट", "कॉल", "जमा",
        "بھیج", "ادائیگی", "حذف", "خرید", "کال", "لیږ", "پیر", "ورکړ", "حذف"
    )

    // इन टूल्स से पहले पूछने की ज़रूरत नहीं (सिर्फ़ वापस/होम/स्क्रॉल)।
    val noConfirm = setOf("go_home", "go_back", "scroll_down")

    private val yesWords = listOf("yes", "yeah", "yep", "ok", "okay", "sure", "haan", "han", "haa", "ji", "हाँ", "हां", "जी", "ठीक", "करो", "ہاں", "جی", "ٹھیک", "هو", "هوکې", "بلې")
    private val noWords = listOf("no", "nahi", "nahin", "nope", "cancel", "stop", "mat", "नहीं", "नही", "मत", "रुको", "نہیں", "نہ", "نه", "نا", "مت")

    fun sensitivePackage(p: String?) = p != null && sensitivePkgWords.any { p.lowercase().contains(it) }
    fun riskyLabel(t: String?) = t != null && riskyLabelWords.any { t.lowercase().contains(it) }

    /** सिर्फ़ साफ़ "हाँ" को हाँ माना जाता है। शक हो तो जवाब "नहीं" है। */
    fun isYes(answer: String): Boolean {
        val words = answer.lowercase().split(" ", ",", ".", "!", "?").filter { it.isNotBlank() }
        if (words.any { it in noWords }) return false
        return words.any { it in yesWords }
    }
}
