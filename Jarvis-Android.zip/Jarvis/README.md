# JARVIS (Android)
हिंदी / اردو / English / پښتو वॉइस असिस्टेंट। "Hey Jarvis" वेक-वर्ड, बैकग्राउंड सर्विस, Accessibility से बेसिक कंट्रोल।
हर action से पहले बोलकर अनुमति माँगता है। बैंक/पेमेंट/पासवर्ड ऐप और send/pay/delete जैसे बटन बंद हैं (Safety.kt)।

## बनाने के स्टेप
1. कंप्यूटर पर Android Studio इंस्टॉल करें (developer.android.com/studio)।
2. Android Studio > Open > यह `Jarvis` फोल्डर चुनें। Gradle sync पूरा होने दें (इंटरनेट चाहिए)।
3. फोन: Settings > About phone > Build number पर 7 बार टैप > Developer options > USB debugging चालू। USB से जोड़ें, "Allow" दबाएँ।
4. Studio में ऊपर अपना फोन चुनें और हरा ▶ Run दबाएँ।
5. ऐप में: API key सेव करें, फिर बटन 2, 3, 4, 5, फिर ▶ JARVIS चालू करें।
6. Accessibility का स्विच ग्रे हो तो: Settings > Apps > JARVIS > ⋮ > "Allow restricted settings"।

## फाइलें
- MainActivity.kt: सेटअप स्क्रीन और अनुमतियाँ
- JarvisService.kt: बैकग्राउंड सुनना, Hey Jarvis, बोलना, हर action पर confirmation
- JarvisAccessibilityService.kt: होम/बैक/टैप/स्क्रॉल/स्क्रीन पढ़ना/स्क्रीनशॉट
- Agent.kt: Claude API से बातचीत और टूल
- Safety.kt: सुरक्षा नियम
